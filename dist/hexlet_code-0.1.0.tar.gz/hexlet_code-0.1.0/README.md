### Hexlet tests and linter status:
[![Actions Status](https://github.com/Spanter/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Spanter/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/cf3f765c65298ecbc9a1/maintainability)](https://codeclimate.com/github/Spanter/python-project-49/maintainability)


### run brain-even
[![asciicast](https://asciinema.org/a/KUr5Zd8mnKCuL0QwTVKyuWKbS.svg)](https://asciinema.org/a/KUr5Zd8mnKCuL0QwTVKyuWKbS)