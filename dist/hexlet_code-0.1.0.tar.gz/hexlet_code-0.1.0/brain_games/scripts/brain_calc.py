#!/usr/bin/env python3
from brain_games.engine import get_start_game
from brain_games.games import calc


# import random """
# import prompt

# MIN_NUMBER = 1
# MAX_NUMBER = 100
# OPERATIONS = ('+', '-', '*')


# def generate_value():
#    first_num = random.randint(MIN_NUMBER, MAX_NUMBER)
#    second_num = random.randint(MIN_NUMBER, MAX_NUMBER)
#    operation = random.choice(OPERATIONS)
#    questions = f'{first_num} {operation} {second_num}'
#    match operation:
#        case '+':
#            correct_answer = first_num + second_num
#            return questions, correct_answer
#        case '-':
#            correct_answer = first_num - second_num
#           return questions, correct_answer
#        case '*':
#            correct_answer = first_num * second_num
#            return questions, correct_answer """


def main():
    get_start_game(calc)


#    print('Welcome to the Brain Games!')
#    name = prompt.string('May I have your name? ').capitalize()
#    print(f'Hello, {name}!')
#    print('What is the result of the expression?')
#    for correct_answer in range(3):
#        questions, correct_answer = generate_value()
#        print(f'Question: {questions}')
#        user_answer = prompt.string('Your answer: ')
#        if user_answer == correct_answer:
#            print('Correct!')
#        else:
#            print(f"'{user_answer}' is wrong answer ;(. Correct answer was "
#                  f"'{correct_answer}'.")
#            print(f"Let's try again, {name}!")
#            return
#    print(f"Congratulations, {name}!")


if __name__ == '__main__':
    main()
